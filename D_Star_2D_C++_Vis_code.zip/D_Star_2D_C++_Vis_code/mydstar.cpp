#include<iostream>
#include<fstream>
#include<tuple>
#include<map>
#include<math.h>
#include<string>
#include "myDstar.h"
using namespace std;


D_star::D_star()
{
	// 初始化
	for (int i = -1; i < 2; i++)
	{
		for (int j = -1; j < 2; j++)
		{
			tuple<int, int> t(i, j);
			double d = sqrt(i * i + j * j);
			this->Alldirec.insert(make_pair(t, d));  //insert是将数据插入,make_pair是将坐标与距离打包成一个组
		}
	}
	this->b.clear();
	this->OPEN.clear();
	this->h.clear();
	this->tag.clear();
	this->path.clear();

	start = make_tuple(2, 2);       // 这里是起始点（填整数，整数也能外推到小数的情况）
	goal = make_tuple(18, 18);      // 这里是终止点

	//添加障碍物信息
	for (int i = 1; i < 11; i++)
	{
		tuple<int, int> ob(5, i);
		this->obs_pos.insert(make_pair(ob, 0));
	}

	for (int i = 8; i < 21; i++)
	{
		tuple<int, int> ob(10, i);
		this->obs_pos.insert(make_pair(ob, 0));
	}

	for (int i = 14; i < 21; i++)
	{
		tuple<int, int> ob(i, 15);
		this->obs_pos.insert(make_pair(ob, 0));
	}

	count = 0;
}

void D_star::check_state(tuple<int, int>&t)  //**检查当前点的h值和状态**
{
	if (this->h.find(t) == this->h.end())    // （没有查到t）find 返回迭代器指向当前查找元素的位置否则返回map::end()位置
	{
		this->h.insert(make_pair(t, 0));     //第一个t为坐标点，第二个为距离
	}
	if (this->tag.find(t) == this->tag.end())
	{
		this->tag.insert(make_pair(t, "New")); //如果未查找到t坐标点，设置当前点的状态为NEW
	}
}

double D_star::get_kmin()   //**获取队列里面所节点中最小的k值**
{
	/*拿到OPEN中最小值*/
	if (!this->OPEN.empty())  //如果open里面不是空的，即存在节点信息
	{
		double min_value = 1000;
		for (auto it = OPEN.begin(); it != OPEN.end(); ++it)  //自动遍历里面的每一个节点
		{
			if (it->second < min_value)     //second取的是一个组里面的第二个位置，即h值
			{
				min_value = it->second;
			}
		}
		return min_value;
	}
	return -1;   //如果open表中为空则返回-1
}

tuple<tuple<int, int>, double>  D_star::min_state()   //**获取open表中具有最小k值得节点**
{
	/*弹出OPEN最小值*/
	if (!this->OPEN.empty())
	{
		double min_value = this->get_kmin();
		for (auto it = OPEN.begin(); it != OPEN.end(); ++it)
		{
			if (it->second == min_value)
			{
				tuple<tuple<int, int>, double> t = make_tuple(it->first, min_value); // 找了一天bug，就是这句double写成int了
				OPEN.erase(it);   //将最小k值的节点从OPEN表中移除
				return t;
			}
		}
	}
	tuple<tuple<int, int>, int> t = make_tuple(tuple<int, int>(-1, -1), -1);  //如果open表为空，进行这步操作
	return t;
}


void D_star::insert(tuple<int, int>&x, double& h_new)
{
	/*插入OPEN表并更新h*/
	double kx;
	if (tag[x] == "New")  //判断节点的状态
	{
		kx = h_new;
	}
	if (tag[x] == "Open")
	{
		kx = OPEN[x] < h_new ? OPEN[x] : h_new;
	}
	if (tag[x] == "Closed")
	{
		kx = h[x] < h_new ? h[x] : h_new;
	}
	/*if (x == tuple<int, int, int>(7, 7, 3))
	{
		int aaa = 0;
	}*/
	OPEN[x] = kx;    //k值始终取该节点所有h值中最小的值
	h[x] = h_new;
	tag[x] = "Open";
}

double D_star::cost(tuple<int, int>&a, tuple<int, int>&b)   //**计算两个节点之间的距离**
{
	/*欧式距离函数，当碰撞时返回一个非常大的值*/
	int x1 = get<0>(a);
	int y1 = get<1>(a);

	int x2 = get<0>(b);
	int y2 = get<1>(b);

	if (!(this->obs_pos.find(a) == this->obs_pos.end()) || !(this->obs_pos.find(b) == this->obs_pos.end()))  //检查两个节点是否都不在障碍物中
	{
		return 1000;
	}
	else
	{
		return sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
	}
}

vector<tuple<int, int>> D_star::children(tuple<int, int>& x)  //**获取子节点坐标**
{
	/*获取子节点坐标*/
	vector<tuple<int, int>> allchild;
	for (auto it = Alldirec.begin(); it != Alldirec.end(); ++it)
	{
		auto direc = it->first;
		int xx = get<0>(x) + get<0>(direc);	  //求中心点周围相邻点的坐标
		int yy = get<1>(x) + get<1>(direc);

		tuple<int, int> point = make_tuple(xx, yy);
		if (xx <= 0 || xx > 20 || yy <= 0 || yy > 20 || !(this->obs_pos.find(point) == this->obs_pos.end())) continue;//判断坐标点是否超出地图边界，且不是障碍物点

		if ((fabs(get<0>(direc)) + fabs(get<1>(direc))) > 1)   //判断是否是斜对角点，然后判断斜对角的左右一边和上下一边是否都有障碍物，出现这种情况不可走斜对角线
		{
			tuple<int, int> new1_point = make_tuple(get<0>(x), yy);  //求的是斜对角点左右一边和上下一边的各一个栅格
			tuple<int, int> new2_point = make_tuple(xx, get<1>(x));

			if (!(this->obs_pos.find(new1_point) == this->obs_pos.end()) &&
				!(this->obs_pos.find(new2_point) == this->obs_pos.end())) continue;
		}

		tuple<int, int> child = make_tuple(xx, yy);   //经过上述检查无误就是一个可行的栅格
		allchild.push_back(child);
	}
	return allchild;
}

double D_star::process_state()    //**论文中的一个核心函数**
{
	/*核心函数*/
	tuple<tuple<int, int>, double> temp = this->min_state();  //找出open表中具有最小k值的节点
	tuple<int, int> x = get<0>(temp);  //取得temp的坐标
	double kold = get<1>(temp);             //取得temp的k值
	this->tag[x] = "Closed";
	if (x == tuple<int, int>(-1, -1)) return -1;   //open表中没有节点信息
	this->check_state(x);   //检查该节点是否是未知节点

	if (kold < h[x])   //一般是在规划完路径后，出现动态障碍物在路径上，才会出现kold<h[x]
	{
		auto allchild = children(x);
		for (auto it = allchild.begin(); it != allchild.end(); ++it)
		{
			tuple<int, int> y = *it;    //使用迭代器遍历，需要将元素解引用才能得到坐标点
			check_state(y);					 //检查是否是未知节点
			double a = h[y] + cost(y, x);    //h[]使用的是里面的第二个值
			if (h[y] <= kold && h[x] > a)    //如果这里条件不成立会跳到else下面执行
			{
				b[x] = y;
				h[x] = a;
			}
		}
	}
	if (kold == h[x])
	{
		auto allchild = children(x);
		for (auto it = allchild.begin(); it != allchild.end(); ++it)
		{
			tuple<int, int> y = *it;
			check_state(y);
			double bb = h[x] + cost(x, y);
			if (tag[y] == "New" || (b[y] == x && h[y] != bb) || (b[y] != x && h[y] > bb))
			{
				b[y] = x;
				insert(y, bb);
			}
		}
	}
	else
	{
		auto allchild = children(x);
		for (auto it = allchild.begin(); it != allchild.end(); ++it)
		{
			tuple<int, int> y = *it;
			check_state(y);
			double bb = h[x] + cost(x, y);
			if (tag[y] == "New" || (b[y] == x && h[y] != bb))      //将x点路径代价提升的信息传播出去
			{
				b[y] = x;
				insert(y, bb);
			}
			else
			{
				if (b[y] != x && h[y] > bb)
				{
					insert(x, h[x]);
				}
				else
				{
					if (b[y] != x && h[x] > h[y] + cost(x, y) && tag[y] == "Closed" && h[y] > kold)
					{
						insert(y, h[y]);
					}
				}
			}
		}
	}
	return get_kmin();
}

void D_star::modify_cost(tuple<int, int>& x)
{
	auto xparent = b[x];
	if (tag[x] == "Closed")   //修改的规划完成的路径上的节点（因为出现动态障碍物在规划完成的路径上）
	{
		double temp = h[xparent] + cost(x, xparent);  //计算父节点被障碍物占据，h值被修改后，现在从父结点到当前节点的h值
		insert(x, temp);    //**修改当前x的h值为temp值,k值不变,该节点状态变为open**
	}
}

void D_star::modify(tuple<int, int>& x)
{
	modify_cost(x);   //进行下面的process_state，但是当前修改的节点会处于open的最上面，也就是直接调用该节点处理
	while (true)
	{
		double kmin = process_state();  //返回一个最小的k值
		if (kmin >= h[x]) break;
	}
}

void D_star::get_path()
{
	/*获取路径*/
	path.clear();
	tuple<int, int> s = goal;
	tuple<int, int> x = start;
	path.push_back(x);
	do
	{
		x = b[x];
		path.push_back(x);
	} while (x != s);
}

void D_star::run()
{
	// D* 算法首先需要计算静态环境下的h
	OPEN[goal] = 0;
	tag[start] = "New";
	while (true)
	{
		cout << "程序正向执行了" << ++count << "个迭代回合。" << endl;
		process_state();
		if (tag[start] == "Closed") break;
	}
	get_path();
	save_path("path1.csv");
	cout << "记录已经保存" << endl;

	// D*面对变化后的环境进行小范围replan
	for (int i = 1; i < 3; ++i)
	{
		//obs_pos = make_tuple(9-i, 9-i, 3); 
		int a1 = get<0>(*(path.begin() + i * 4 + 2));
		int a2 = get<1>(*(path.begin() + i * 4 + 2));
		NEW_OBS = make_tuple(a1, a2);
		this->obs_pos.insert(make_pair(NEW_OBS, 0)); // 新的障碍位置（这里可以设置为动态变化的位置，一个道理）
		auto s = start;
		while (s != goal)
		{
			auto sparent = b[s];
			if (cost(s, sparent) > 500)
			{
				modify(s);
				continue;
			}
			s = sparent;
		}
		get_path();
		char load_dir[10];
		char load_obs[10];
		sprintf_s(load_obs, "%s%d%s", "Obs", i + 1, ".csv");
		save_obs(load_obs);
		sprintf_s(load_dir, "%s%d%s", "path", i + 1, ".csv");  //文件缓存区、文件名
		save_path(load_dir);
		cout << "记录已经保存" << endl;
	}
}

void D_star::save_obs(string load_obs)
{
	/*保存数据*/
	ofstream ofs;      //ofstream 文件写操作 内存写入存储设备
	ofs.open(load_obs, ios::out);
	
	int x = get<0>(NEW_OBS);
	int y = get<1>(NEW_OBS);
	ofs << x << "," << y << endl;
	
	ofs.close();
}
void D_star::save_path(string load_dir)
{
	/*保存数据*/
	ofstream ofs;      //ofstream 文件写操作 内存写入存储设备
	ofs.open(load_dir, ios::out);
	for (auto it = path.begin(); it != path.end(); ++it)
	{
		tuple<int, int>xy = *it;
		int x = get<0>(xy);
		int y = get<1>(xy);
		if (it != path.end() - 1)
		{
			ofs << x << "," << y << endl;
		}
		else
		{
			ofs << x << "," << y;
		}
	}
	ofs.close();
}
