# include<iostream>
# include "myDstar.h"
#include<tuple>
using namespace std;

int main()
{
	D_star D;
	D.run();

	return 0;
}