clc
clear
close all

start_node=[2,2];
target_node = [18, 18];
% obstacle1=[5,1;5,2;5,3;5,4;5,5;5,6;5,7;5,8;5,9;5,10];
% obstacle2=[10,20;10,19;10,18;10,17;10,16;10,15;10,14;10,13;10,12;10,11;10,10;10,9;10,8];
% obstacle3=[14,15;15,15;16,15;17,15;18,15;18,15;19,15;20,15];

path1 = csvread("path1.csv");  %·����Ϣ
path2 = csvread("path2.csv");
path3 = csvread("path3.csv");

obs2=csvread("Obs2.csv");      %�ϰ���䶯��Ϣ
obs3=csvread("Obs3.csv");
%���ϰ��䶯
figure(1);
for i = 1:20
    plot([0,20], [i, i], 'k');   %������
    hold on
end
    
for j = 1:20
     plot([j, j], [0, 20], 'k'); %������
end

axis equal
xlim([0, 20]);
ylim([0, 20]);  

fill([start_node(1)-1, start_node(1), start_node(1), start_node(1)-1],...
    [start_node(2)-1, start_node(2)-1 , start_node(2), start_node(2)], 'g');
text(start_node(1),start_node(2),"start");

fill([target_node(1)-1, target_node(1), target_node(1), target_node(1)-1],...
    [target_node(2)-1, target_node(2)-1 , target_node(2), target_node(2)], 'r');
text(target_node(1),target_node(2),"target");

fill([4 5 5 4],[0 0 10 10],'c');
fill([9 10 10 9],[7 7 20 20],'c');
fill([13 20 20 13],[14 14 15 15],'c');

%���滮��·��
num = size(path1,1);
for i = 2:num-1
    fill([path1(i,1)-1, path1(i,1), path1(i,1), path1(i,1)-1],...
    [path1(i,2)-1, path1(i,2)-1, path1(i,2), path1(i,2)], 'k');
end

%��һ���ϰ���䶯��
figure(2);
for i = 1:20
    plot([0,20], [i, i], 'k');   %������
    hold on
end
    
for j = 1:20
     plot([j, j], [0, 20], 'k'); %������
end

axis equal
xlim([0, 20]);
ylim([0, 20]);  

fill([start_node(1)-1, start_node(1), start_node(1), start_node(1)-1],...
    [start_node(2)-1, start_node(2)-1 , start_node(2), start_node(2)], 'g');
text(start_node(1),start_node(2),"start");

fill([target_node(1)-1, target_node(1), target_node(1), target_node(1)-1],...
    [target_node(2)-1, target_node(2)-1 , target_node(2), target_node(2)], 'r');
text(target_node(1),target_node(2),"target");

fill([4 5 5 4],[0 0 10 10],'c');
fill([9 10 10 9],[7 7 20 20],'c');
fill([13 20 20 13],[14 14 15 15],'c');
fill([obs2(1,1)-1, obs2(1,1), obs2(1,1),obs2(1,1)-1],...
     [obs2(1,2)-1, obs2(1,2)-1, obs2(1,2), obs2(1,2)], 'c');

%���滮��·��
num = size(path2,1);
for i = 2:num-1
    fill([path2(i,1)-1, path2(i,1), path2(i,1), path2(i,1)-1],...
    [path2(i,2)-1, path2(i,2)-1, path2(i,2), path2(i,2)], 'k');
end

%�ڶ����ϰ���䶯��
figure(3);
for i = 1:20
    plot([0,20], [i, i], 'k');   %������
    hold on
end
    
for j = 1:20
     plot([j, j], [0, 20], 'k'); %������
end

axis equal
xlim([0, 20]);
ylim([0, 20]);  

fill([start_node(1)-1, start_node(1), start_node(1), start_node(1)-1],...
    [start_node(2)-1, start_node(2)-1 , start_node(2), start_node(2)], 'g');
text(start_node(1),start_node(2),"start");

fill([target_node(1)-1, target_node(1), target_node(1), target_node(1)-1],...
    [target_node(2)-1, target_node(2)-1 , target_node(2), target_node(2)], 'r');
text(target_node(1),target_node(2),"target");

fill([4 5 5 4],[0 0 10 10],'c');
fill([9 10 10 9],[7 7 20 20],'c');
fill([13 20 20 13],[14 14 15 15],'c');
fill([obs2(1,1)-1, obs2(1,1), obs2(1,1),obs2(1,1)-1],...
     [obs2(1,2)-1, obs2(1,2)-1, obs2(1,2), obs2(1,2)], 'c');
fill([obs3(1,1)-1, obs3(1,1), obs3(1,1),obs3(1,1)-1],...
     [obs3(1,2)-1, obs3(1,2)-1, obs3(1,2), obs3(1,2)], 'c');

%���滮��·��
num = size(path3,1);
for i = 2:num-1
    fill([path3(i,1)-1, path3(i,1), path3(i,1), path3(i,1)-1],...
    [path3(i,2)-1, path3(i,2)-1, path3(i,2), path3(i,2)], 'k');
end

