function dis = distance(node1, node2)
    dis = sqrt((node1(1) - node2(1))^2 + (node1(2) - node2(2))^2);
end

